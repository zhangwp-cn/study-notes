#!/bin/bash

# 设置文件根路径
if [ ${0:0:1} == '/' ]; then
    ROOT_PATH=$(dirname $0)
else
    ROOT_PATH=$(dirname $(pwd)/$0)
fi

echo ${ROOT_PATH}
cd ${ROOT_PATH}

mkdir -p elasticsearch/data/
mkdir -p elasticsearch/logs/
chmod 777 -R elasticsearch/data/
chmod 777 -R elasticsearch/logs/

CONTAINER_NAME='elasticsearch-single'
docker run -dt \
           --restart=always \
           --name=${CONTAINER_NAME} \
           --network=host \
           -e "discovery.type=single-node" \
           -v ${ROOT_PATH}/elasticsearch/elasticsearch.yml:/usr/share/elasticsearch/config/elasticsearch.yml \
           -v ${ROOT_PATH}/elasticsearch/data/:/usr/share/elasticsearch/data/ \
           -v ${ROOT_PATH}/elasticsearch/logs/:/usr/share/elasticsearch/logs/ \
           elasticsearch:7.11.1

sleep 20

docker exec -it ${CONTAINER_NAME} /usr/share/elasticsearch/bin/elasticsearch-setup-passwords auto
