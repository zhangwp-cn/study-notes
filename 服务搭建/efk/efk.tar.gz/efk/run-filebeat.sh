#!/bin/bash

# 设置文件根路径
if [ ${0:0:1} == '/' ]; then
    ROOT_PATH=$(dirname $0)
else
    ROOT_PATH=$(dirname $(pwd)/$0)
fi

echo ${ROOT_PATH}
cd ${ROOT_PATH}

mkdir -p filebeat/logs/
chmod 777 -R filebeat/logs/

CONTAINER_NAME='filebeat-single'
docker run -dt \
           --restart=always \
           --name=${CONTAINER_NAME} \
           --network=host \
           -v ${ROOT_PATH}/filebeat/filebeat.yml:/usr/share/filebeat/filebeat.yml \
           -v ${ROOT_PATH}/filebeat/logs/:/usr/share/filebeat/logs/ \
           elastic/filebeat:7.11.1
