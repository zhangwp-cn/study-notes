#!/bin/bash

# 设置文件根路径
if [ ${0:0:1} == '/' ]; then
    ROOT_PATH=$(dirname $0)
else
    ROOT_PATH=$(dirname $(pwd)/$0)
fi

echo ${ROOT_PATH}
cd ${ROOT_PATH}

mkdir -p kibana/data/
mkdir -p kibana/logs/
chmod 777 -R kibana/data/
chmod 777 -R kibana/logs/

CONTAINER_NAME='kibana-single'
docker run -dt \
           --restart=always \
           --name=${CONTAINER_NAME} \
           --network=host \
           -v ${ROOT_PATH}/kibana/config/:/usr/share/kibana/config/ \
           -v ${ROOT_PATH}/kibana/data/:/usr/share/kibana/data/ \
           -v ${ROOT_PATH}/kibana/logs/:/usr/share/kibana/logs/ \
           kibana:7.11.1
